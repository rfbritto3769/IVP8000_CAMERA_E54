/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

struct camera_async_descriptor CAMERA_OV7670;

struct usart_sync_descriptor EDGB_COM;

struct i2c_m_sync_desc PCC_SSCB;

void EXTERNAL_IRQ_0_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, EIC_GCLK_ID, CONF_GCLK_EIC_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_EIC_bit(MCLK);

	// Set pin direction to input
	gpio_set_pin_direction(PA12, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PA12,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PA12, PINMUX_PA12A_EIC_EXTINT12);

	// Set pin direction to input
	gpio_set_pin_direction(PA13, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(PA13,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PA13, PINMUX_PA13A_EIC_EXTINT13);

	ext_irq_init();
}

void EVENT_SYSTEM_0_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, EVSYS_GCLK_ID_1, CONF_GCLK_EVSYS_CHANNEL_1_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBBMASK_EVSYS_bit(MCLK);

	event_system_init();
}

void CAMERA_OV7670_PORT_init(void)
{

	gpio_set_pin_function(PA14, PINMUX_PA14K_PCC_CLK);

	gpio_set_pin_function(PA16, PINMUX_PA16K_PCC_DATA0);

	gpio_set_pin_function(PA17, PINMUX_PA17K_PCC_DATA1);

	gpio_set_pin_function(PA18, PINMUX_PA18K_PCC_DATA2);

	gpio_set_pin_function(PA19, PINMUX_PA19K_PCC_DATA3);

	gpio_set_pin_function(PA20, PINMUX_PA20K_PCC_DATA4);

	gpio_set_pin_function(PA21, PINMUX_PA21K_PCC_DATA5);

	gpio_set_pin_function(PA22, PINMUX_PA22K_PCC_DATA6);

	gpio_set_pin_function(PA23, PINMUX_PA23K_PCC_DATA7);
}

void CAMERA_OV7670_CLOCK_init(void)
{
	hri_mclk_set_APBDMASK_PCC_bit(MCLK);
}

void CAMERA_OV7670_init(void)
{
	CAMERA_OV7670_CLOCK_init();
	camera_async_init(&CAMERA_OV7670, PCC);
	CAMERA_OV7670_PORT_init();
}

void EDGB_COM_PORT_init(void)
{

	gpio_set_pin_function(PB25, PINMUX_PB25D_SERCOM2_PAD0);

	gpio_set_pin_function(PB24, PINMUX_PB24D_SERCOM2_PAD1);
}

void EDGB_COM_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_CORE, CONF_GCLK_SERCOM2_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_SLOW, CONF_GCLK_SERCOM2_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBBMASK_SERCOM2_bit(MCLK);
}

void EDGB_COM_init(void)
{
	EDGB_COM_CLOCK_init();
	usart_sync_init(&EDGB_COM, SERCOM2, (void *)NULL);
	EDGB_COM_PORT_init();
}

void PCC_SSCB_PORT_init(void)
{

	gpio_set_pin_pull_mode(PD08,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PD08, PINMUX_PD08C_SERCOM7_PAD0);

	gpio_set_pin_pull_mode(PD09,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_OFF);

	gpio_set_pin_function(PD09, PINMUX_PD09C_SERCOM7_PAD1);
}

void PCC_SSCB_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM7_GCLK_ID_CORE, CONF_GCLK_SERCOM7_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM7_GCLK_ID_SLOW, CONF_GCLK_SERCOM7_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	hri_mclk_set_APBDMASK_SERCOM7_bit(MCLK);
}

void PCC_SSCB_init(void)
{
	PCC_SSCB_CLOCK_init();
	i2c_m_sync_init(&PCC_SSCB, SERCOM7);
	PCC_SSCB_PORT_init();
}

void delay_driver_init(void)
{
	delay_init(SysTick);
}

void system_init(void)
{
	init_mcu();

	EXTERNAL_IRQ_0_init();

	EVENT_SYSTEM_0_init();

	CAMERA_OV7670_init();

	EDGB_COM_init();

	PCC_SSCB_init();

	delay_driver_init();
}
